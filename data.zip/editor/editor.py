import json
import logging
import os
from typing import Optional, Tuple, TYPE_CHECKING

import pygame
import pygame_gui

from editor.tools import ToolsPanel
from utils.utilities import Color, StairwellIDGenerator, ToolType, load_layout, pick_csv_file, pick_save_csv_file, save_layout, save_building_json, get_dpi_scale, rTemp
from ui.slider import create_control_panel

if TYPE_CHECKING:
    from core.grid import Grid
    from core.spot import Spot

logger = logging.getLogger(__name__)

# Global constant for white color - accessed once at import time
WHITE = Color.WHITE.value

# Editor class
class Editor:
    def __init__(
        self,
        win: pygame.Surface,
        rows: int,
        bg_image: Optional[pygame.Surface] = None,
        filename: str = "layout_csv\\layout_1.csv",
        max_starts = 3,
        floor: int = 0
    ) -> None:
        from core.grid import Grid
        
        self.win = win
        self.rows = rows
        self.bg_image = bg_image
        self.filename = filename
        self.max_starts = max_starts
        self.floor = floor

        # compute DPI scaling factor to size UI elements
        self.scale = get_dpi_scale(pygame.display.get_wm_info()['window'])

        # Calculate width based on current window size
        win_width, win_height = win.get_size()
        tools_width = int(200 * self.scale)
        self.width = min(win_width - tools_width, win_height)
        self.width = max(self.width, int(200 * self.scale))  # minimum
        self.panel_x = win_width - tools_width
        
        # Grid and state
        self.grid_obj = Grid(rows, self.width, floor)
        self.tools_panel = ToolsPanel(self.panel_x, 0, tools_width, win_height, scale=self.scale)
        self.tools_panel.floor = floor
        self.current_tool = "MATERIAL"
        self.current_filename = filename
        self.bg_image_loaded = False
        
        # Mouse dragging state
        self.mouse_dragging = False
        self.drag_action = None  # 'place' or 'erase'

        # JSON multi-floor layout paths (set when a JSON building file is loaded)
        self.json_floor_layouts = None
        # Pending JSON save path (set when user saves as .json)
        self.pending_json_save = None
        self.last_cell = None
        
        # Ruler overlay state
        self.show_ruler = False
        
        # Initialize GUI
        self.manager = pygame_gui.UIManager((win_width, win_height))
        self._setup_ui_buttons()

        # Simulation parameter sliders
        self.temp = rTemp()
        self._create_sliders()
    
    def _create_sliders(self) -> None:
        """Slider between material buttons and bottom instructions text."""
        # 6 tools = 3 rows of 2; each row is (80+10)*scale tall, starting at panel.y+50
        button_height  = int(80 * self.scale)
        padding        = int(10 * self.scale)
        num_rows       = 3
        buttons_bottom = self.tools_panel.rect.y + int(50 * self.scale) + num_rows * (button_height + padding)

        # Bottom instructions sit at rect.bottom - 130*scale
        instructions_top = self.tools_panel.rect.bottom - int(130 * self.scale)

        slider_w = int(170 * self.scale)
        slider_x = self.panel_x + (int(200 * self.scale) - slider_w) // 2
        slider_y = buttons_bottom + int(20 * self.scale) + button_height 

        if (instructions_top - slider_y) < int(100 * self.scale):
            slider_y = buttons_bottom + int(10 * self.scale) + button_height

        self.slider_group = create_control_panel(
            manager=self.manager,
            x=slider_x,
            y=slider_y,
            temp_obj=self.temp,
            scale=self.scale,
        )
        
    def _setup_ui_buttons(self) -> None:
        """Ruler | Save | Load — three equal buttons at the bottom of the panel."""
        win_width, win_height = self.win.get_size()
        panel_x       = win_width - int(200 * self.scale)
        button_y      = win_height - int(40 * self.scale)
        button_height = int(30 * self.scale)
        button_gap    = int(6 * self.scale)
        button_width  = int((200 * self.scale - 4 * button_gap) / 3)

        ruler_x = panel_x + button_gap
        save_x  = ruler_x + button_width + button_gap
        load_x  = save_x  + button_width + button_gap

        self.ruler_button = pygame_gui.elements.UIButton(
            relative_rect=pygame.Rect((ruler_x, button_y), (button_width, button_height)),
            text="Ruler: Off",
            manager=self.manager
        )

        self.save_button = pygame_gui.elements.UIButton(
            relative_rect=pygame.Rect((save_x, button_y), (button_width, button_height)),
            text="Save",
            manager=self.manager
        )

        self.load_button = pygame_gui.elements.UIButton(
            relative_rect=pygame.Rect((load_x, button_y), (button_width, button_height)),
            text="Load",
            manager=self.manager
        )
    
    def _handle_window_resize(self, event: pygame.event.Event) -> bool:
        if event.type != pygame.VIDEORESIZE:
            return False

        # Resize window
        self.win = pygame.display.set_mode(event.size, pygame.RESIZABLE)

        # DPI may have changed during the resize/move
        from utils.utilities import get_dpi_scale
        self.scale = get_dpi_scale(pygame.display.get_wm_info()['window'])

        win_width, win_height = event.size
        tools_width = int(200 * self.scale)

        # Grid takes remaining width, square aspect
        grid_pixel_width = min(win_width - tools_width, win_height)
        grid_pixel_width = max(grid_pixel_width, int(200 * self.scale))
        #grid_pixel_width = win_width - tools_width

        self.width = grid_pixel_width
        self.panel_x = win_width - tools_width

        # Resize grid geometry
        self.grid_obj.cell_size = self.width // self.rows
        self.grid_obj.update_geometry(self.grid_obj.cell_size)
        self.grid_obj.width = self.width

        # Move tools panel and update its scale in case DPI changed
        self.tools_panel.scale = self.scale
        self.tools_panel.rect.x = win_width - tools_width
        self.tools_panel.rect.height = win_height
        self.tools_panel._init_buttons()

        # Recreate UI manager for new size
        self.manager = pygame_gui.UIManager((win_width, win_height))
        self._setup_ui_buttons()
        self._create_sliders()
        return True

    def _load_initial_layout(self) -> None:
        """Load initial layout if file exists"""
        try:
            start, exits = load_layout(self.grid_obj.grid, self.filename)
            if start:
                self.grid_obj.start = start
            if bool(exits):
                self.grid_obj.exits = exits
            # remember the file so simulations can reload it on reset
            self.grid_obj.layout_filename = self.filename
            self.grid_obj.mark_material_cache_dirty()
        except FileNotFoundError:
            pass  # Start with empty grid
    
    def _handle_ui_events(self, event: pygame.event.Event) -> None:
        """Handle UI button events"""
        if event.type == pygame_gui.UI_BUTTON_PRESSED:
            if event.ui_element == self.save_button:
                self._save_layout_dialog()
            elif event.ui_element == self.load_button:
                self._load_layout_dialog()
            elif event.ui_element == self.ruler_button:
                self._toggle_ruler()
    
    def _handle_tools_panel_events(self, event: pygame.event.Event) -> None:
        """Handle tools panel selection events"""
        if event.pos[0] >= self.panel_x:  # Click in tools panel
            tool_type, selected_material = self.tools_panel.handle_event(event)
            if tool_type is not None:
                self._process_tool_selection(tool_type, selected_material)
    
    def _process_tool_selection(self, tool_type: ToolType, selected_material) -> None:
        """Process tool selection from tools panel"""
        
        if tool_type == ToolType.MATERIAL:
            self.current_tool = "MATERIAL"
            self.tools_panel.current_material = selected_material
        elif tool_type == ToolType.START:
            self.current_tool = "START"
            logger.debug("Start position mode - click on grid to place start")
        elif tool_type == ToolType.END:
            self.current_tool = "END"
            logger.debug("End position mode - click on grid to place end")
        elif tool_type == ToolType.FIRE_SOURCE:
            self.current_tool = "FIRE_SOURCE"
            logger.debug("Fire source mode - click on grid to place fire source")
        elif tool_type == ToolType.STAIR:
            self.current_tool = "STAIR"
            logger.debug("Stairwell mode - click on grid to place stairwell")
        elif tool_type == ToolType.SPRINKLER:
            self.current_tool = "SPRINKLER"

    def _handle_grid_click(self, event: pygame.event.Event) -> None:
        """Handle mouse clicks in the grid area"""
        row, col = self.grid_obj.get_clicked_pos(event.pos)
        
        if row is not None and col is not None and self.grid_obj.in_bounds(row, col):
            spot = self.grid_obj.get_spot(row, col)
            
            if event.button == 1:  # Left click - place
                self.mouse_dragging = True
                self.drag_action = 'place'
                self._place_on_grid(row, col, spot)
                self.last_cell = (row, col)
            
            elif event.button == 3:  # Right click - erase
                self.mouse_dragging = True
                self.drag_action = 'erase'
                self._erase_from_grid(spot)
                self.last_cell = (row, col)
    
    def _place_on_grid(self, row: int, col: int, spot: "Spot") -> None:
        """Place items on the grid based on current tool"""
        if self.current_tool != "START" and spot.is_start():
            if spot in self.grid_obj.start:
                self.grid_obj.start.remove(spot)
        
        if self.current_tool != "END" and spot.is_end():
            self.grid_obj.remove_exit(spot)

        if self.current_tool == "START":
            if spot in self.grid_obj.start:
                return
            
            if len(self.grid_obj.start) < self.max_starts:
                spot.make_start()
                self.grid_obj.start.append(spot)
                self.grid_obj.mark_material_cache_dirty()
            else:
                logger.warning(f"Maximum number of start positions ({self.max_starts}) reached. Cannot place more.")
        
        elif self.current_tool == "END":
            self.grid_obj.add_exit(spot)
            spot.make_end()
            self.grid_obj.mark_material_cache_dirty()
        
        elif self.current_tool == "STAIR":
            # If this exact cell is already a stairwell, keep that id.
            existing_stair_id = StairwellIDGenerator.find_stair_at_cell(spot.row, spot.col)

            if existing_stair_id is not None:
                stair_id = existing_stair_id
            elif self.floor == 0:
                # Floor 0 always creates a brand-new stairwell id.
                stair_id = StairwellIDGenerator.new_stair()
            else:
                # Higher floors consume unpaired floor-0 stair IDs in order.
                linked_id = StairwellIDGenerator.next_link_target(target_floor=self.floor, anchor_floor=0)
                if linked_id is not None:
                    stair_id = linked_id
                else:
                    # If target floor already has as many stairs as floor 0, create a new id.
                    stair_id = StairwellIDGenerator.new_stair()

            # Add this floor's spot to the stairwell
            spot.make_stairwell(stair_id=stair_id)
            StairwellIDGenerator.add(stair_id=stair_id, floor=self.floor, spot=spot)

            self.grid_obj.mark_material_cache_dirty()
            
        elif self.current_tool == "MATERIAL":
            material_id = self.tools_panel.get_current_material()
            self.grid_obj.set_material(row, col, material_id)

        elif self.current_tool == "FIRE_SOURCE":
            self.grid_obj.fire_sources.add((row, col))
            spot.set_as_fire_source()
            logger.debug("Fire source placed")

        elif self.current_tool == "SPRINKLER":
            spot.set_as_sprinkler()
            
    def _erase_from_grid(self, spot: "Spot") -> None:
        """Erase items from the grid"""
        if spot.is_start():
            if spot in self.grid_obj.start:
                self.grid_obj.start.remove(spot)

        if self.grid_obj.is_exit(spot):
            self.grid_obj.remove_exit(spot)
        
        # Remove stairwell
        if spot.is_stairwell:
            stair_id = spot.stair_id
            if stair_id is not None and stair_id in StairwellIDGenerator.stairs:
                if self.floor in StairwellIDGenerator.stairs[stair_id]:
                    del StairwellIDGenerator.stairs[stair_id][self.floor]
            spot.is_stairwell = False
            spot.stair_id = None
        
        spot.reset()
        self.grid_obj.mark_material_cache_dirty()
    
    def _handle_mouse_drag(self, event: pygame.event.Event) -> None:
        """Handle mouse dragging for continuous drawing/erasing"""
        if event.pos[0] < self.width:  # Only process if in grid area
            row, col = self.grid_obj.get_clicked_pos(event.pos)
            
            if row is not None and col is not None and self.grid_obj.in_bounds(row, col):
                if self.last_cell != (row, col):
                    spot = self.grid_obj.get_spot(row, col)
                    
                    if self.drag_action == 'place':
                        if self.current_tool == "MATERIAL":
                            material_id = self.tools_panel.get_current_material()
                            self.grid_obj.set_material(row, col, material_id)
                    
                    elif self.drag_action == 'erase':
                        spot.reset()
                        if spot == self.grid_obj.start:
                            self.grid_obj.start = None
                        if spot in self.grid_obj.exits:
                            self.grid_obj.exits.remove(spot)
                        self.grid_obj.mark_material_cache_dirty()
                    
                    self.last_cell = (row, col)
    
    def _handle_keyboard_events(self, event: pygame.event.Event) -> Optional[bool]:
        """Handle keyboard shortcuts"""
        if event.key == pygame.K_i:  # Toggle background image
            self._toggle_background_image()
        
        elif event.key == pygame.K_m:  # Back to material mode
            self.current_tool = "MATERIAL"
            logger.debug("Material mode")
        
        elif event.key == pygame.K_s:  # Save layout
            save_layout(self.grid_obj.grid, self.current_filename)
            logger.debug("Layout saved")
        
        elif event.key == pygame.K_l:  # Load layout
            logger.debug("Loading layout... %s", self.filename)
            self._load_from_file(self.filename)
        
        elif event.key == pygame.K_SPACE and self.grid_obj.start: #and bool(self.grid_obj.exits):
            logger.info("Starting simulation...")
            return True  # Signal to exit editor
        
        elif event.key == pygame.K_ESCAPE or event.key == pygame.K_q:
            return False  # Signal to quit program
        
        return None
    
    def _toggle_background_image(self) -> None:
        """Toggle background image visibility"""
        if not self.bg_image_loaded:
            self.bg_image_loaded = True
            if self.bg_image:
                self.bg_image.set_alpha(150)
        else:
            self.bg_image_loaded = False
            if self.bg_image:
                self.bg_image.set_alpha(0)
    
    def _toggle_ruler(self) -> None:
        """Toggle ruler overlay visibility"""
        self.show_ruler = not self.show_ruler
        self.ruler_button.set_text("Ruler: On" if self.show_ruler else "Ruler: Off")
        logger.debug("Ruler overlay %s", "enabled" if self.show_ruler else "disabled")
    
    def _draw_ruler_overlay(self) -> None:
        """Draw scale ruler overlay showing physical distances in meters"""
        from utils.utilities import rTemp
        
        temp_constants = rTemp()
        cell_size_m = temp_constants.CELL_SIZE_M
        cell_size_px = self.grid_obj.cell_size
        
        # Font for labels
        font = pygame.font.SysFont(None, int(20 * self.scale))
        
        # Draw tick marks every 5 cells on vertical and horizontal edges
        tick_interval = 5  # cells
        tick_length = int(15 * self.scale)
        
        # Vertical ruler (left side)
        for i in range(0, self.rows + 1, tick_interval):
            y = i * cell_size_px
            distance_m = i * cell_size_m
            
            # Draw tick
            pygame.draw.line(self.win, (0, 0, 200), (0, y), (tick_length, y), 2)
            
            # Draw label
            label = font.render(f"{distance_m:.1f}m", True, (255, 200, 0))
            self.win.blit(label, (tick_length + 5, y - 10))
        
        # Horizontal ruler (top)
        for i in range(0, self.rows + 1, tick_interval):
            x = i * cell_size_px
            distance_m = i * cell_size_m
            
            # Draw tick
            pygame.draw.line(self.win, (0, 0, 200), (x, 0), (x, tick_length), 2)
            
            # Draw label
            label = font.render(f"{distance_m:.1f}m", True, (255, 200, 0))
            self.win.blit(label, (x - 20, tick_length + 5))
        
        # Draw grid info in top-right corner
        total_size_m = self.rows * cell_size_m
        info_text = f"Grid: {self.rows}×{self.rows} cells = {total_size_m:.1f}m × {total_size_m:.1f}m ({cell_size_m}m/cell)"
        info_surface = font.render(info_text, True, (255, 255, 255))
        info_bg = pygame.Surface((info_surface.get_width() + 20, info_surface.get_height() + 10))
        info_bg.set_alpha(200)
        info_bg.fill((50, 50, 50))
        self.win.blit(info_bg, (10, 10))
        self.win.blit(info_surface, (20, 15))
    
    def _save_layout_dialog(self) -> None:
        """Open save dialog and save layout (CSV for single floor, JSON for building)"""
        save_filename = pick_save_csv_file()
        if not save_filename:
            return

        if save_filename.lower().endswith('.json'):
            # Store JSON path — run_editor will finalize after all floors
            self.pending_json_save = save_filename
            logger.debug("Building will be saved to %s after all floors are done", save_filename)
        else:
            save_layout(self.grid_obj.grid, filename=save_filename)
            self.current_filename = save_filename
            # if the user explicitly saved the layout, update the grid's
            # remembered filename so resets will use the new file
            self.grid_obj.layout_filename = save_filename
    
    def _load_layout_dialog(self) -> None:
        """Open load dialog and load layout (CSV or JSON building file)"""
        load_filename = pick_csv_file()
        if not load_filename:
            return

        if load_filename.lower().endswith('.json'):
            self._load_json_building(load_filename)
        else:
            self._load_from_file(load_filename)
            self.current_filename = load_filename

    def _load_json_building(self, json_path: str) -> None:
        """Load a JSON building file, set floor count, and load this floor's layout."""
        with open(json_path, 'r') as f:
            building_data = json.load(f)

        floors = building_data.get('floors', [])
        if not floors:
            logger.warning("JSON building file has no floors: %s", json_path)
            return

        json_dir = os.path.dirname(json_path)

        # Resolve layout paths relative to the JSON file's directory
        floor_layouts = []
        for floor_entry in sorted(floors, key=lambda x: x.get('floor', 0)):
            layout_path = os.path.join(json_dir, floor_entry['layout'])
            floor_layouts.append(layout_path)

        # Store for run_editor to use on subsequent floors
        self.json_floor_layouts = floor_layouts

        # Set floor count so run_editor creates the right number of floors
        rTemp().NUM_FLOORS = len(floor_layouts)

        # Load this floor's layout
        if self.floor < len(floor_layouts):
            self._load_from_file(floor_layouts[self.floor])
            self.current_filename = floor_layouts[self.floor]

        logger.info("Loaded JSON building with %d floors from %s", len(floor_layouts), json_path)
    
    def _load_from_file(self, filename: str) -> None:
        """Load layout from a specific file"""
        # remember the source so resets can go back to it
        self.grid_obj.layout_filename = filename

        # Clear old state
        self.grid_obj.start = None
        self.grid_obj.exits.clear()
        
        # Reset all spots
        for r in range(self.rows):
            for c in range(self.width // self.rows):
                self.grid_obj.grid[r][c].reset()
        
        # Load from file
        start, exits = load_layout(self.grid_obj.grid, filename)
        
        if start:
            self.grid_obj.start = start
        if exits and bool(exits):
            self.grid_obj.exits = exits

        self.grid_obj.mark_material_cache_dirty()
        
        # Hide background image during load
        self.bg_image_loaded = False
        if self.bg_image:
            self.bg_image.set_alpha(0)
        
        logger.debug("Layout loaded from %s", filename)
    
    def _import_layout(self) -> None:
        """Import layout from CSV file"""
        csv_filename = pick_csv_file()
        if csv_filename:
            self._load_from_file(csv_filename)
            logger.debug("Layout imported")
    
    def _export_layout(self) -> None:
        """Export layout to CSV file"""
        save_filename = pick_save_csv_file()
        if save_filename:
            save_layout(self.grid_obj.grid, save_filename)
            logger.debug("Layout exported")
    
    def run(self) -> Optional["Grid"] | None:
        """Main editor loop"""
        clock = pygame.time.Clock()
        while True:
            time_delta = clock.tick(60) / 1000.0
            self.win.fill(WHITE)
            
            # Draw everything
            self.grid_obj.draw(self.win, self.tools_panel, self.bg_image)
            
            # Draw ruler overlay if enabled
            if self.show_ruler:
                self._draw_ruler_overlay()
            
            # Draw white separator bar between grid and tools
            win_width, win_height = self.win.get_size() #pygame method to get current window size
            separator_x = self.panel_x #use current window width
            
            pygame.draw.rect(
                self.win, 
                WHITE, 
                (separator_x, 0, 2, win_height)
            )# Draw white separator

            for event in pygame.event.get():
                if self._handle_window_resize(event):
                    continue  # Skip further processing if resized

                if event.type == pygame.QUIT:
                    return None
                
                # Handle different event types
                if event.type == pygame_gui.UI_BUTTON_PRESSED:
                    self._handle_ui_events(event)

                elif event.type == pygame_gui.UI_HORIZONTAL_SLIDER_MOVED:
                    if hasattr(self, 'slider_group'):
                        self.slider_group.handle_event(event)

                elif event.type == pygame_gui.UI_DROP_DOWN_MENU_CHANGED:
                    if hasattr(self, 'slider_group'):
                        self.slider_group.handle_event(event)
                
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if event.pos[0] >= self.width:
                        self._handle_tools_panel_events(event)
                    else:
                        self._handle_grid_click(event)
                
                elif event.type == pygame.MOUSEMOTION and self.mouse_dragging:
                    self._handle_mouse_drag(event)
                
                elif event.type == pygame.MOUSEBUTTONUP:
                    self.mouse_dragging = False
                    self.drag_action = None
                    self.last_cell = None
                
                elif event.type == pygame.KEYDOWN:
                    result = self._handle_keyboard_events(event)
                    if result is True:
                        return self.grid_obj
                    elif result is False:
                        return None
                
                self.manager.process_events(event)
            
            # Update UI
            self.manager.update(time_delta)
            self.manager.draw_ui(self.win)
            pygame.display.update()

# LEGACY FUNCTION (for compatibility)
def run_editor(win: pygame.surface.Surface, rows: int, num_of_floors = None,bg_image=None, filename="layout_csv\\layout_2.csv", max_starts = 3):
    """Legacy function - creates an Editor instance and runs it"""
    from core.grid import Grid

    editor = Editor(win, rows, bg_image, filename, max_starts = max_starts, floor=0)
    result = editor.run()
    if result is None:
        return None
    
    # Capture JSON floor layouts if a JSON building file was loaded
    json_floor_layouts = editor.json_floor_layouts
    grid_width = editor.width  # reuse the same grid width for all floors

    # Read NUM_FLOORS only after floor 0 editor closes (slider has been set)
    chosen_floors = int(rTemp().NUM_FLOORS)
    results = [result]
    
    for f in range(1, chosen_floors):
        if json_floor_layouts and f < len(json_floor_layouts):
            # Auto-load floor from JSON — no interactive editor needed
            grid = Grid(rows, grid_width, f)
            start, exits = load_layout(grid.grid, json_floor_layouts[f])
            if start:
                grid.start = start
            if exits:
                grid.exits = exits
            grid.layout_filename = json_floor_layouts[f]
            grid.mark_material_cache_dirty()
            results.append(grid)
        else:
            editor = Editor(win, rows, bg_image, filename, floor=f)
            result = editor.run()
            if result is None:
                return None
            results.append(result)

    # If a JSON save was requested, write the building file + all floor CSVs
    # in each iteration of the editor, the pending_json_save variable 
    # is reset to None even after saving(click save button), so it will only save
    # if we click save at the last floor.
    if editor.pending_json_save:
        save_building_json(editor.pending_json_save, results)

    print(StairwellIDGenerator.stairs)
    return results